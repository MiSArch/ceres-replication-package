package org.misarch

import io.gatling.javaapi.core.ScenarioBuilder

// This will be set dynamically by the Gatling service
val scenarios = mapOf<ScenarioBuilder, String>()