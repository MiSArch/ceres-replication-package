plugins {}
rootProject.name = "gatling-server"